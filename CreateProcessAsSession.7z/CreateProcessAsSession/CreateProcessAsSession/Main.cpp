﻿#include <Windows.h>
#include <UserEnv.h>
#include <WtsApi32.h>
#include <tchar.h>
#include <stdio.h>
#pragma comment(lib, "UserEnv.lib")
#pragma comment(lib, "WtsApi32.lib")


BOOL EnableDebugPrivilege(BOOL fEnable)
{
    //调试权限可以让该进程能够读取其他进程的信息
    BOOL fok = FALSE;
    HANDLE hToken;//存放获得的令牌

    //获取当前进程的令牌
    /*
     * 这个函数的第一个参数是当前进程的句柄
     * 第二个参数是进程对获得的令牌有哪些操作权限，权限有很多
     * 第三个参数是存放令牌的句柄的地址
     */
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken))
    {
        //开始激活当前令牌的调试权限，调试权限就算有一般也是不开通的，因为权限太大了
        //一定要用完了就关掉

        TOKEN_PRIVILEGES tp;//结构体，表示令牌权限
        /*
         *这个结构体有很多个成员变量，保存在数组里
         *有一个唯一本地标识符 LUID 一个不可能重复的很大的数字，这个东西和GUID是同一个东西
         */

         //只启动调试权限，所以权限的个数是一个
        tp.PrivilegeCount = 1;

        /*
         * 下面一个函数，查找并且获得本地调试权限的LUID，LUID存储在tp结构体里
         * 如果第一个参数是NULL，代表本地的权限的LUID
         */
         //LookupPrivilegeValue函数获得本地系统的调试权限的LUID，还没有给令牌
        LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tp.Privileges[0].Luid);

        //下面一句话，在tp.Privilege[0].Attributes属性中，设置是开启这个权限还是关闭这个权限
        tp.Privileges[0].Attributes = fEnable ? SE_PRIVILEGE_ENABLED : 0;
        //当Attributes = SE_PRIVILEGE_ENABLE时，激活权限
        //当Attributes = 0时，关闭权限
        //权限是从上一个函数里获得的

        //AdjustTokenPrivileges函数激活或者关闭tp中给定的权限
        AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);

        //这句话确认激活是否成功
        fok = (GetLastError() == ERROR_SUCCESS);
        CloseHandle(hToken);
    }
    return fok;

}

bool ServerRunWndProcess(DWORD pid)
{
    HANDLE hToken = NULL;

    HANDLE hProcess = OpenProcess(MAXIMUM_ALLOWED, FALSE, pid);

    if (!OpenProcessToken(hProcess, TOKEN_ALL_ACCESS, &hToken))
    {
        return false;
    }

    HANDLE hTokenDup = NULL;
    bool bRet = DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityIdentification, TokenPrimary, &hTokenDup);
    if (!bRet || hTokenDup == NULL)
    {
        CloseHandle(hToken);
        return false;
    }

    DWORD dwSessionId = WTSGetActiveConsoleSessionId();
    //把服务hToken的SessionId替换成当前活动的Session(即替换到可与用户交互的winsta0下)
    if (!SetTokenInformation(hTokenDup, TokenSessionId, &dwSessionId, sizeof(DWORD)))
    {
        DWORD nErr = GetLastError();
        CloseHandle(hTokenDup);
        CloseHandle(hToken);
        return false;
    }

    STARTUPINFO si;
    ZeroMemory(&si, sizeof(STARTUPINFO));

    si.cb = sizeof(STARTUPINFO);
    si.lpDesktop = _T("WinSta0\\Default");
    si.wShowWindow = SW_SHOW;
    si.dwFlags = STARTF_USESHOWWINDOW /*|STARTF_USESTDHANDLES*/;

    //创建进程环境块
    LPVOID pEnv = NULL;
    bRet = CreateEnvironmentBlock(&pEnv, hTokenDup, FALSE);
    if (!bRet)
    {
        CloseHandle(hTokenDup);
        CloseHandle(hToken);
        return false;
    }

    if (pEnv == NULL)
    {
        CloseHandle(hTokenDup);
        CloseHandle(hToken);
        return false;
    }

    //在活动的Session下创建进程
    PROCESS_INFORMATION processInfo;
    ZeroMemory(&processInfo, sizeof(PROCESS_INFORMATION));
    DWORD dwCreationFlag = NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE | CREATE_UNICODE_ENVIRONMENT;

    if (!CreateProcessAsUser(hTokenDup, NULL, "powershell.exe", NULL, NULL, FALSE, dwCreationFlag, pEnv, NULL, &si, &processInfo))
    {
        DWORD nRet = GetLastError();
        CloseHandle(hTokenDup);
        CloseHandle(hToken);
        return false;
    }

    DestroyEnvironmentBlock(pEnv);
    CloseHandle(hTokenDup);
    CloseHandle(hToken);

    return true;
}


DWORD LaunchWin7SessionProcess(DWORD pid ,DWORD dwSessionId,LPTSTR lpCommand)
{
    DWORD dwRet = 0;
    PROCESS_INFORMATION pi;
    STARTUPINFO si;
    //DWORD dwSessionId;//当前会话的ID
    HANDLE hUserToken = NULL;//当前登录用户的令牌
    HANDLE hUserTokenDup = NULL;//复制的用户令牌
    HANDLE hPToken = NULL;//进程令牌
    DWORD dwCreationFlags;
    //得到当前活动的会话ID，即登录用户的会话ID  
    //dwSessionId = WTSGetActiveConsoleSessionId();
    do
    {
        WTSQueryUserToken(dwSessionId, &hUserToken);//读取当前登录用户的令牌信息  
        dwCreationFlags = NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE;//创建参数  

        ZeroMemory(&si, sizeof(STARTUPINFO));
        ZeroMemory(&pi, sizeof(pi));

        si.cb = sizeof(STARTUPINFO);

        si.lpDesktop = "winsta0\\default";//指定创建进程的窗口站，Windows下唯一可交互的窗口站就是WinSta0\Default  

        TOKEN_PRIVILEGES tp;
        LUID luid;

        //打开进程令牌  
        //if (!OpenProcessToken(GetCurrentProcess(),
        HANDLE hProcess = OpenProcess(MAXIMUM_ALLOWED, FALSE, pid);

        if (!OpenProcessToken(hProcess,
            TOKEN_ADJUST_PRIVILEGES |
            TOKEN_QUERY |
            TOKEN_DUPLICATE |
            TOKEN_ASSIGN_PRIMARY |
            TOKEN_ADJUST_SESSIONID |
            TOKEN_READ |
            TOKEN_WRITE, &hPToken))
        {
            dwRet = GetLastError();
            break;
        }

        //查找DEBUG权限的UID  
        if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &luid))
        {
            dwRet = GetLastError();
            break;
        }

        //设置令牌信息  
        tp.PrivilegeCount = 1;
        tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

        //复制当前用户的令牌  
        if (!DuplicateTokenEx(hPToken, MAXIMUM_ALLOWED, NULL, SecurityIdentification,
            TokenPrimary, &hUserTokenDup))
        {
            dwRet = GetLastError();
            break;
        }

        //设置当前进程的令牌信息  
        if (!SetTokenInformation(hUserTokenDup, TokenSessionId, (void*)&dwSessionId, sizeof(DWORD)))
        {
            dwRet = GetLastError();
            break;
        }

        //应用令牌权限  
        if (!AdjustTokenPrivileges(hUserTokenDup, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
            (PTOKEN_PRIVILEGES)NULL, NULL))
        {
            dwRet = GetLastError();
            break;
        }

        //创建进程环境块，保证环境块是在用户桌面的环境下  
        LPVOID pEnv = NULL;
        if (CreateEnvironmentBlock(&pEnv, hUserTokenDup, TRUE))
        {
            dwCreationFlags |= CREATE_UNICODE_ENVIRONMENT;
        }
        else
        {
            pEnv = NULL;
        }

        //创建用户进程  
        if (!CreateProcessAsUser(hUserTokenDup, NULL, lpCommand, NULL, NULL, FALSE,
            dwCreationFlags, pEnv, NULL, &si, &pi))
        {
            dwRet = GetLastError();
            break;
        }
    } while (0);

    //关闭句柄  
    if (NULL != hUserToken)
    {
        CloseHandle(hUserToken);
    }

    if (NULL != hUserTokenDup)
    {
        CloseHandle(hUserTokenDup);
    }

    if (NULL != hPToken)
    {
        CloseHandle(hPToken);
    }

    return dwRet;

}



void EP_ShowError(char* pszText)
{
    char szErr[MAX_PATH] = { 0 };
    ::wsprintf(szErr, "%s Error[%d]\n", pszText, ::GetLastError());
    ::MessageBox(NULL, szErr, "ERROR", MB_OK);
}


BOOL EnbalePrivileges(HANDLE hProcess, char* pszPrivilegesName)
{
    HANDLE hToken = NULL;
    LUID luidValue = { 0 };
    TOKEN_PRIVILEGES tokenPrivileges = { 0 };
    BOOL bRet = FALSE;
    DWORD dwRet = 0;


    // 打开进程令牌并获取具有 TOKEN_ADJUST_PRIVILEGES 权限的进程令牌句柄
    bRet = ::OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES, &hToken);
    if (FALSE == bRet)
    {
        EP_ShowError("OpenProcessToken");
        return FALSE;
    }
    // 获取本地系统的 pszPrivilegesName 特权的LUID值
    bRet = ::LookupPrivilegeValue(NULL, pszPrivilegesName, &luidValue);
    if (FALSE == bRet)
    {
        EP_ShowError("LookupPrivilegeValue");
        return FALSE;
    }
    // 设置提升权限信息
    tokenPrivileges.PrivilegeCount = 1;
    tokenPrivileges.Privileges[0].Luid = luidValue;
    tokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    // 提升进程令牌访问权限
    bRet = ::AdjustTokenPrivileges(hToken, FALSE, &tokenPrivileges, 0, NULL, NULL);
    if (FALSE == bRet)
    {
        EP_ShowError("AdjustTokenPrivileges");
        return FALSE;
    }
    else
    {
        // 根据错误码判断是否特权都设置成功
        dwRet = ::GetLastError();
        if (ERROR_SUCCESS == dwRet)
        {
            return TRUE;
        }
        else if (ERROR_NOT_ALL_ASSIGNED == dwRet)
        {
            EP_ShowError("ERROR_NOT_ALL_ASSIGNED");
            return FALSE;
        }
    }

    return FALSE;
}

void ShowError(char* pszText)
{
    char szErr[MAX_PATH] = { 0 };
    ::wsprintf(szErr, "%s Error[%d]\n", pszText, ::GetLastError());
    ::MessageBox(NULL, szErr, "ERROR", MB_OK);
}


// 使用 ZwCreateThreadEx 实现远线程注入
BOOL ZwCreateThreadExInjectDll(DWORD dwProcessId, char* pszDllFileName)
{
    HANDLE hProcess = NULL;
    SIZE_T dwSize = 0;
    LPVOID pDllAddr = NULL;
    FARPROC pFuncProcAddr = NULL;
    HANDLE hRemoteThread = NULL;
    DWORD dwStatus = 0;

    // 打开注入进程，获取进程句柄
    hProcess = ::OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
    if (NULL == hProcess)
    {
        ShowError("OpenProcess");
        return FALSE;
    }
    // 在注入进程中申请内存
    dwSize = 1 + ::lstrlen(pszDllFileName);
    pDllAddr = ::VirtualAllocEx(hProcess, NULL, dwSize, MEM_COMMIT, PAGE_READWRITE);
    if (NULL == pDllAddr)
    {
        ShowError("VirtualAllocEx");
        return FALSE;
    }
    // 向申请的内存中写入数据
    if (FALSE == ::WriteProcessMemory(hProcess, pDllAddr, pszDllFileName, dwSize, NULL))
    {
        ShowError("WriteProcessMemory");
        return FALSE;
    }
    // 加载 ntdll.dll
    HMODULE hNtdllDll = ::LoadLibrary("ntdll.dll");
    if (NULL == hNtdllDll)
    {
        ShowError("LoadLirbary");
        return FALSE;
    }
    // 获取LoadLibraryA函数地址
    pFuncProcAddr = ::GetProcAddress(::GetModuleHandle("Kernel32.dll"), "LoadLibraryA");
    if (NULL == pFuncProcAddr)
    {
        ShowError("GetProcAddress_LoadLibraryA");
        return FALSE;
    }
    // 获取ZwCreateThread函数地址
#ifdef _WIN64
    typedef DWORD(WINAPI* typedef_ZwCreateThreadEx)(
        PHANDLE ThreadHandle,
        ACCESS_MASK DesiredAccess,
        LPVOID ObjectAttributes,
        HANDLE ProcessHandle,
        LPTHREAD_START_ROUTINE lpStartAddress,
        LPVOID lpParameter,
        ULONG CreateThreadFlags,
        SIZE_T ZeroBits,
        SIZE_T StackSize,
        SIZE_T MaximumStackSize,
        LPVOID pUnkown);
#else
    typedef DWORD(WINAPI* typedef_ZwCreateThreadEx)(
        PHANDLE ThreadHandle,
        ACCESS_MASK DesiredAccess,
        LPVOID ObjectAttributes,
        HANDLE ProcessHandle,
        LPTHREAD_START_ROUTINE lpStartAddress,
        LPVOID lpParameter,
        BOOL CreateSuspended,
        DWORD dwStackSize,
        DWORD dw1,
        DWORD dw2,
        LPVOID pUnkown);
#endif
    typedef_ZwCreateThreadEx ZwCreateThreadEx = (typedef_ZwCreateThreadEx)::GetProcAddress(hNtdllDll, "ZwCreateThreadEx");
    if (NULL == ZwCreateThreadEx)
    {
        ShowError("GetProcAddress_ZwCreateThread");
        return FALSE;
    }
    // 使用 ZwCreateThreadEx 创建远线程, 实现 DLL 注入
    dwStatus = ZwCreateThreadEx(&hRemoteThread, PROCESS_ALL_ACCESS, NULL, hProcess, (LPTHREAD_START_ROUTINE)pFuncProcAddr, pDllAddr, 0, 0, 0, 0, NULL);
    if (NULL == hRemoteThread)
    {
        ShowError("ZwCreateThreadEx");
        return FALSE;
    }
    // 关闭句柄
    ::CloseHandle(hProcess);
    ::FreeLibrary(hNtdllDll);

    return TRUE;
}


int main(int argc, char* argv[])
{
    // 提升当前进程令牌权限
    EnbalePrivileges(::GetCurrentProcess(), SE_DEBUG_NAME);
    // 远线程注入 DLL
#ifndef _WIN64
    BOOL bRet = ZwCreateThreadExInjectDll(atoi(argv[1]), argv[2]);
#else 
    BOOL bRet = ZwCreateThreadExInjectDll(atoi(argv[1]), argv[2]);
#endif
    if (FALSE == bRet)
    {
        printf("Inject Dll Error.\n");
        return 0;
    }
    printf("Inject Dll OK.\n");
    system("pause");
    return 0;


    //ServerRunWndProcess(atoi(argv[1]));
    //LaunchWin7SessionProcess(atoi(argv[1]), atoi(argv[2]), "powershell.exe");

}