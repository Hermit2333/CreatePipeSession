﻿// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <stdint.h>


bool CreateConnectNamedPipe(HANDLE* hPipe, char* pipeName)
{
    *hPipe = CreateNamedPipeA(
        pipeName,
        PIPE_ACCESS_DUPLEX,
        PIPE_TYPE_BYTE,
        100,
        1 * 1024,
        1 * 1024,
        1000,
        NULL
    );
    if (*hPipe == NULL || *hPipe == INVALID_HANDLE_VALUE) {
        printf("Failed to create outbound pipe instance.\n");
        return false;
    }
    printf("[Main] NamedPipe %s created ! Waiting connection...\n", pipeName);
    BOOL result = ConnectNamedPipe(*hPipe, NULL);
    if (!result) {
        printf("[Main] Failed to make connection on named pipe.\n");
        CloseHandle(*hPipe);
        return false;
    }
    printf("[Main] Client connected !\n");
    return true;
}


bool OpenNamedPipe(HANDLE* hPipe, char* pipeName)
{
    while (1) {
        *hPipe = CreateFileA(
            pipeName,
            GENERIC_READ | GENERIC_WRITE,
            0,
            NULL,
            OPEN_EXISTING,
            0,
            NULL);

        if (*hPipe != INVALID_HANDLE_VALUE)
            break;

        if (GetLastError() != ERROR_PIPE_BUSY) {
            printf("[Main] Waiting for NamedPipe... \n");
            Sleep(1000);
        }
        else {
            if (!WaitNamedPipeA(pipeName, 1000)) {
                printf("[Main] Error when wait NamedPipe\n");
            }
        }
    }
    DWORD dwMode = PIPE_TYPE_BYTE;
    BOOL result = SetNamedPipeHandleState(
        *hPipe,
        &dwMode,
        NULL,
        NULL);
    if (!result) {
        return false;
    }
    printf("[Main] Connected to server NamedPipe !\n");
    return true;
}

bool GetPipeTry(HANDLE hPipe, uint8_t* data, uint64_t size, bool timeout)
{
    DWORD avalaibleBytes;
    uint32_t TryCount = 0;
    do {
        PeekNamedPipe(hPipe, NULL, 0, NULL, &avalaibleBytes, NULL);
        if (avalaibleBytes >= size) {
            DWORD numBytesRead = 0;
            BOOL result = ReadFile(hPipe, data, (uint32_t)size, &numBytesRead, NULL);
            (void)result;
            return true;
        }
        else {
            if ((TryCount & 0xFFFF) == 0xFFFF) {
                Sleep(0); //5
            }
            else {
                TryCount++;
            }
        }
    } while (timeout == false);
    return false;
}

bool GetPipe(HANDLE hPipe, uint8_t* data, uint64_t size)
{
    return GetPipeTry(hPipe, data, size, false);
}

DWORD PutPipe(HANDLE hPipe, uint8_t* data, uint64_t size)
{
    DWORD numBytesWritten = 0;
    BOOL result = WriteFile(hPipe, data, (uint32_t)size, &numBytesWritten, NULL);
    (void)result;
    return numBytesWritten;
}


#include "windows.h"
#include <iostream>
using namespace std;

#define BUF_SIZE 4096
// 定义管道名 , 如果是跨网络通信 , 则在圆点处指定服务器端程序所在的主机名
#define EXAMP_PIPE   L"\\\\.\\PIPE\\EB3F2E4B_52E2_40F9_A17D_B4A2588F23AB"   




BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        // 创建命名管道
        HANDLE hPipe = NULL;
        hPipe = CreateNamedPipe(
            EXAMP_PIPE,
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_MESSAGE |
            PIPE_READMODE_MESSAGE |
            PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            BUF_SIZE,
            BUF_SIZE,
            0,
            NULL);

        if (hPipe == INVALID_HANDLE_VALUE)
        {
            cout << "Create Read Pipe Error" << endl;
            return FALSE;
        }


        cout << "Wait for the connection" << endl;

        // 等待客户端的连接
        if (!ConnectNamedPipe(hPipe, NULL))
        {
            cout << "Connect Failed" << endl;
            return FALSE;
        }

        DWORD dwReturn = 0;
        char szBuffer[BUF_SIZE] = { 0 };

        // 向客户端发送数据
        cout << "Wait for input" << endl;
        cin >> szBuffer;
        if (!WriteFile(hPipe, szBuffer, strlen(szBuffer), &dwReturn, NULL))
        {
            cout << "Write Failed" << endl;
        }

        // 读取客户端数据
        memset(szBuffer, 0, BUF_SIZE);
        if (ReadFile(hPipe, szBuffer, BUF_SIZE, &dwReturn, NULL))
        {
            szBuffer[dwReturn] = '\0';
            cout << szBuffer << endl;
        }
        else
        {
            cout << "Read Failed" << endl;
        }

        DisconnectNamedPipe(hPipe);
        CloseHandle(hPipe);
        return 0;
    }


    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

